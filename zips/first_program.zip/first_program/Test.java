package fundamentals.first_program;

public class Test {
    public static void main(String[] args) {
        System.out.println("My name is Josh");
        System.out.println("I am 29 years old.");
        System.out.println("I am from Northern Virginia.");
    }
}